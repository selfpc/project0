<!DOCTYPE html>
<html>
<head>
<title> My webpage</title>


</head>

<body>
<h2>HTML4 Organization</h2>
<div class="header"> This is header</dive>
<div class="nav">This is navigation bar</div>
<div class="section">This is the section</div>
<div class="footer">This is the footer</div>
  </body>
</html>
